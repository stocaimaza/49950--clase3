/* SUGAR SYNTAX */

//¿Que es la sugar syntax? La utilización de operadores avanzados con la idea de simplificar el código. 

//1) Plantillas Literales: las usamos a traves de las backsticks ``
//alt + 96. Me permite simplificar la concatenación de datos. 

let nombre = "Pepe Argento";
let trabajo = "Zapatería";

let mensaje = `${nombre} trabaja en una ${trabajo}`;
console.log(mensaje);

//2) Operador ternario: es una simplificación de la estructura if/else: 

//sintaxis: condicion ? codigoSiEsVerdad : codigoSiEsFalso; 

let llueve = true; 

console.log(llueve ? "tortas fritas y netflix" : "vamos a hacer que corremos");

let respuesta = llueve ? "tortas fritas" : "hacemos un asado"; 
console.log(respuesta);

//3) Operador Spread: Operador de propagación. 
//Se utiliza con elementos iterables (arrays, objetos) enviando cada uno de sus elementos como parámetros a una función. 

const nombres = ["Juan", "Pedro", "Maria", "Jose"];

console.log(nombres);

//¿Que pasa si yo uso el operador spread? 

console.log(...nombres);

console.log(nombres[0], nombres[1], nombres[2], nombres[3]);

//Copiar objetos: 

const alumno = {
    nombre: "Coki",
    apellido: "Argento", 
    edad: 37
}

//No puedo hacer esto: 
const alumnoDos = alumno; 
//Si hago esto, estoy copiando la referencia en memoria. 

alumno.nombre = "Tomas";


console.log(alumno);
console.log(alumnoDos);

//Para copiar objetos de forma correcta tenemos que utilizar el operador SPREAD. 

const alumnoTres = {...alumno}; 

//Copiar arrays: 

const a = [1,2,3];
const b = [4,5,6];

const nuevoArray = [...b, ...a]; 
console.log(nuevoArray);

//4)Desestructuración de Objetos: 
//Es una expresión de JS que permite desempaquetar valores de arrays u objetos en distintas variables. 

const bart = {
    nombre: "Bart",
    apellido: "Simpson", 
    edad: 10
}

//Hago lo siguiente: 

let {nombre:nombrecirijillo, apellido, edad} = bart; 

console.log(nombrecirijillo);
console.log(apellido);
console.log(edad);

//5) Desestructuración de arrays: 

let frutas = ["Manzana", "Pera", "Naranja", "Vino"];

let [ ,,firulais, coky] = frutas; 

//console.log(fruta0);
console.log(firulais);
console.log(coky);

//6) Acceso condicional a un objeto: 

const empleado = null;

console.log(empleado?.nombre);

//alert("ayudame locoo!!");

//Operador &&
//Además de evaluar una condición, nos permite ejecutar un código si la condición se cumple. 

//Ejemplo: 

let hambre = false; 

hambre && console.log("21:42hs hora de comer"); 


//Operador ||
//Evalua una condición y si es falsa ejecuta el código. 

let sueño = false; 

sueño || console.log("Puedo seguir estudiando");

//Funciones de orden superior: es aquella que recibe por parámetro otra función o retorna después de su ejecución una función. 

class Producto {
    constructor(nombre, precio) {
        this.nombre = nombre;
        this.precio = precio; 
    }
}

const fideos = new Producto("Fideos", 200);
const harina = new Producto("Harina", 250);
const gaseosa = new Producto("Coca Cola", 180); 
const pan = new Producto("Pan", 120);

const arrayProductos = [fideos, harina, gaseosa, pan]; 

//¿Cuales son los metodos de busqueda y transformacion que vamos a usar? 
//find, filter, some, map y reduce. 

//Find: busca un elemento en el array y retorna el primero que coincida. 

const buscado = arrayProductos.find(item => item.nombre === "Coca Colaa"); 
console.log(buscado);

//Retorna el primer elemento que cumpla con la condición, si no lo encuentra retorna: undefined. 

//Filter: retorna un nuevo array con los elementos que cumplan con la condición. 

const arrayProductosMenos200 = arrayProductos.filter(item => item.precio < 200);
console.log(arrayProductosMenos200);

//Some: retorna un booleano (true o false) si encuentra o no al producto. 

const hayFideos = arrayProductos.some(item => item.nombre === "Fideos");
console.log("¿Hay fideos?" + hayFideos );

//Map: me permite crear un nuevo array con todos los elementos del original pero transformados. 

const arrayProductosConIva = arrayProductos.map(item => {
    return {
        nombre: item.nombre,
        precio: item.precio * 1.21
    }
})

console.log(arrayProductosConIva);

//Reduce: nos permite obtener un único valor después de iterar sobre un array. 
//Ejemplo, el total de un carrito. 

//Podemos trabajar con dos parámetros: un acumulador y el elemento a operar. 
//Tambien debemos colocar el valor inicial del acumulador. 

let totalPrecio = arrayProductos.reduce((acumulador, item) => acumulador + item.precio,100);

console.log(totalPrecio);

